package com.bryanollivie.lojinha.data.model

class ReturnBase {

    var data: List<Any>? = null
    var result: String? = ""
    var offset: Int? = 0
    var total: Int? = 0

}
